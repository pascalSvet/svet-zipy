package zipy_elements;

public class ElementsBuying {
	
	
//// cart: ////////////////////////////////////////////////////////

	public static final String ProductFramed_next = "/html/body/div[@role='dialog']//div[@class='featherlight-content quick-view']/span[1]/span[@class='ico ico--arrow-slider']";
	public static final String ProductFramed_close = "/html/body/div[4]/div/div/div/span/span";
	public static final String Product_addToCart = "/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']//div[@class='product__buy-buttons']/a/span[@class='ico ico--cart']";	
	public static final String Product_addedToCart = "/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']/div[@class='product__main']//div[@class='product__buy-buttons-buy-now']/a[2]";
	public static final String Product_openCart = "/html//div[@id='topbar']//span[@class='ico ico--cart']";
	public static final String Product_closeCart = "/html//div[@id='topbar']//span[@class='ico ico--cart']";
	public static final String Product_cartFrame = "/html/body/div[1]/div[4]/div/div[2]/div/div";
	public static final String Product_cartFrame_dev = "/html/body/div[1]/div[3]/div/div[2]/div/div";
	public static final String Product_cartRemove = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[1]//span[@class='ico']";
	public static final String Product_cartRemove_dev = "/html/body/div[1]/div[3]/div/div[2]//div[@class='user-goods-list']/div[1]/div[1]//span[@class='ico']";
	public static final String Product_cartRemove2 = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[2]//span[@class='ico']";
	public static final String Product_cartRemove3 = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[3]//span[@class='ico']";
	public static final String Product_cart_moveToFavorites = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[1]//span[@class='ico ico--pin']";	
	public static final String Product_cart_returnToCart = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[1]//span[@class='ico ico--cart']";	
	public static final String Product_cartPay = "/html/body/div[1]/div[*]/div/div[2]//a[@href='/payment/']";
	public static final String Product_cartIsEmpty = "/html/body/div[1]/div[4]/div/div[2]//strong[.='הסל שלך ריק.']";
	public static final String Product_cart_finalSum = "/html/body/div[1]/div[4]/div/div[2]//span[@class='sum__price']";
	public static final String Product_cart_finalSum_mobile = "//*[@id=\"paymentInfoForm\"]/div/div[5]/div/table/tfoot/tr/td[1]/span/span/span[1]";
	public static final String Product_cart_oldPrice = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[2]//span[@class='price__old']";
	public static final String Product_cart_newPrice = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[1]//span[@class='price__current']";
	public static final String Product_cart_topBarQuantity = "/html//div[@id='topbar']/div[@class='default']/div[4]/span[2]//span[@class='cart-count-value']";
	public static final String Product_cart_quantity = "/html/body/div[1]/div[4]/div/div[2]//div[@class='user-goods-list']/div[1]/div[1]//input";
	public static final String Product_cart_quantity_mobile = "/html//div[@id='wrapper']/div[2]/div[2]/div[@class='user-goods-list']/div[1]/div//input";
	public static final String Product_cart_quantity10plus_mobile = "/html//div[@id='wrapper']/div[2]/div[2]/div[@class='user-goods-list']/div[1]/div//input";
	public static final String Product_cart_quantityDrop = "/html//div[@id='wrapper']/div[2]/div[2]/div[@class='user-goods-list']/div[1]/div//div[@class='counter']/a";
	public static final String Product_cart_quantityDrop_1 = "/html//div[@role='dialog']//div[@id='popup_cart-count']/div[@class='cart-count']/a[1]";
	public static final String Product_cart_quantityDrop_10 = "/html//div[@role='dialog']//div[@id='popup_cart-count']/div[@class='cart-count']/a[10]";

	public static final String paymentSuccess_page = "https://www.zipy.co.il/payment/success";

	
//// favorites: ////////////////////////////////////////////////////////

	public static final String Product_favoritesButton = "/html//div[@id='topbar']//span[@class='ico ico--pin']";
	public static final String Product_favoritesButton_popup = "/html/body/div[@role='dialog']//div[@class='featherlight-content-wrap']//section//div[@class='product__pin']/a/span[@class='product__pin-anchor']";
	public static final String Product_favoritesFrame = "/html/body/div[1]/div[4]/div/div[1]/div/div";
	public static final String Product_favoritesFrame_dev = "/html/body/div/div/div/div//div[@class='user-goods-list']/div/div";
	public static final String Product_favoritesRemove = "/html/body/div[1]/div[4]/div/div[1]//div[@class='user-goods-list']/div/div[1]//span[@class='ico']";
	public static final String Product_favoritesRemove_dev = "/html/body/div/div/div/div//div[@class='user-goods-list']/div/div//span[@class='ico']";
	public static final String Product_closeFavorites = "/html//div[@id='topbar']/div[@class='default']/div[5]/span[1]/strong[@class='topbar__items-link-count']";
	public static final String Product_openFavorites = "/html//div[@id='topbar']/div[@class='default']/div[5]/span[1]/strong[@class='topbar__items-link-count']";
	public static final String Product_favoritesTitle = "/html/body/div[1]/div[4]/div/div[1]//ul[@class='user-goods-list-heading']/li[@class='title']";
	public static final String Product_favorites_topBarQuantity = "//*[@id=\"topbar\"]/div[2]/div[4]/span[1]/strong/span";

	
	
////product page: ////////////////////////////////////////////////////////

	public static final String Product_variationsFirst ="/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']/div[@class='product__main']/div[@class='sell-wrap']/div[@class='buy-options']/table[@class='product__params']/tbody/tr[1]/td/div[@class='product__params-selection']/div[@class='field__field']/div[@class='select type-variations']/div[1]/div[@class='selectric']//span[@class='selectric-option-text']";
	public static final String Product_variationsFirstAgain = "/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']/div[@class='product__main']//div[@class='buy-options']/table[@class='product__params']/tbody/tr[1]/td//div[@class='select type-variations']/div[1]/div[@class='selectric']//span[@class='selectric-option-text']";
	public static final String Product_variationsFirst_i = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[";
	public static final String Product_variationsFirst_1 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[2]";
	public static final String Product_variationsFirst_1_img = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[2]/span/img";
	public static final String Product_variationsFirst_1_imgSelected = "//*[@id='wrapper']/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[2]/span/img";
	public static final String Product_variationsFirst_2 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[3]";
	public static final String Product_variationsFirst_2_img = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[3]/span/img";
	public static final String Product_variationsFirst_2_imgSelected = "//*[@id='wrapper']/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[3]/span/img";
	public static final String Product_variationsFirst_3 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[4]";
	public static final String Product_variationsFirst_5 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[6]";
	public static final String Product_variationsFirst_5_img = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[6]/span/img";
	public static final String Product_variationsFirst_dropdownFrame = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]";
	public static final String Product_variationsFirst_text ="//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]/div[2]/p/span/span";

	public static final String Product_variationsSecond ="/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']/div[@class='product__main']/div[@class='sell-wrap']/div[@class='buy-options']/table[@class='product__params']/tbody/tr[2]/td/div[@class='product__params-selection']/div[@class='field__field']/div[@class='select type-variations']/div[1]/div[@class='selectric']//span[@class='selectric-option-text']";
	public static final String Product_variationsSecondAgain ="/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']/div[@class='product__main']//div[@class='buy-options']/table[@class='product__params']//div[@class='product__params-selection']/div[@class='field__field']/div[@class='select type-variations']/div[1]/div[@class='selectric']/span[@class='ico ico--arrow-triangle-down']";
	public static final String Product_variationsSecond_1 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[2]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[2]";
	public static final String Product_variationsSecond_2 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[2]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[3]";
	public static final String Product_variationsSecond_i = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[2]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[";
	public static final String Product_variationsSecond_dropdownFrame = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[2]/td/div/div[2]/div[1]/div[1]";
	public static final String Product_variationsSecond_text ="//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[2]/td/div/div[2]/div[1]/div[1]/div[2]/p/span/span";

	public static final String Product_variationsThird ="/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']/div[@class='product__main']/div[@class='sell-wrap']/div[@class='buy-options']/table[@class='product__params']/tbody/tr[3]/td/div[@class='product__params-selection']/div[@class='field__field']/div[@class='select type-variations']/div[1]/div[@class='selectric']//span[@class='selectric-option-text']";
	public static final String Product_variationsThird_1 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[3]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[2]";
	public static final String Product_variationsThird_i = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[3]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[";
	public static final String Product_variationsThird_2 = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[3]/td/div/div[2]/div[1]/div[1]/div[3]/div/ul/li[3]";
	public static final String Product_variationsThird_dropdownFrame = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[3]/td/div/div[2]/div[1]/div[1]";
	public static final String Product_chooseWeight = "/html//input[@id='accessibility-product-weight-form-input']";

	public static final String Product_variationsFrameClosed = "selectric-wrapper";
	
	public static final String Product_plusOne = "/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']//div[@class='product__buy-buttons-buy-now']/a[1]/span[@class='button-buy-amount-text']";
	public static final String Product_quantityManual_mobile = "/html//input[@id='accessibility-buy-product-amount']";
	public static final String Product_quantityPlus = "/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']/div[@class='product__main']//div[@class='buy-options']/table[@class='product__params']//div[@class='product__counter']/button[2]";
	public static final String Product_quantityPlusAgain = "/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']/div[@class='product__main']//div[@class='buy-options']/table[@class='product__params']//div[@class='product__counter']/button[2]";
	public static final String Product_titleFromPicture = "//img[@class='product__specs-image']"; //atribute:alt
	public static final String Product_titleFromPicture_amazon = "/html/head/meta[6]";  //atribute:content
	public static final String Product_titleFromPopup = "/html//div[@role='dialog']//div[@class='featherlight-content-wrap']//section//h1[@class='product__title']";
	public static final String Product_added = "/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']/div[@class='product__main']//div[@class='product__buy-buttons-buy-now']/a[2]//span[@class='amount-text']";
	public static final String Product_heron = "//div[@id='wrapper']//main[@role='main']/section[@class='notfound']//div[@class='notfound__text-title']";
	public static final String Product_price = "/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']//div[@class='product__table-wrapper']/table[@class='product__params']//td[@class='product__params-sale']/span/span[@class='value']";
	public static final String Product_discount = "/html//div[@id='wrapper']/div[3]//section/div[@class='product__body']//div[@class='product__table-wrapper']/table[@class='product__params']/thead/tr[2]/td[@class='product__params-sale']/span/span[@class='value']";
	public static final String Product_delivery = "/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']//div[@class='product__table-wrapper']/table[@class='product__params']//span[@class='shipping-price']/span[@class='value']";
	public static final String Product_pin = "/html//div[@id='wrapper']//section//div[@class='product__pin']/a/span[@class='product__pin-anchor']";
	public static final String Product_dailyDealsTitle = "/html/body//section[@class='one-block']//main[@role='main']/section//div[@class='daily__heading-deal']";

	public static final String PayNow_button = "/html//div[@id='wrapper']/div[@class='product__page']//section/div[@class='product__body']/div[@class='product__main']//div[@class='product__buy-buttons-buy-now']/a[2]//span[@class='button__inner']";
	public static final String Product_payment_Remove = "/html//div[@id='wrapper']/div[2]/div[2]/div[@class='user-goods-list']/div[1]/div[1]//span[@class='ico']";
	public static final String Product_payment_Remove_mobile = "/html//div[@id='wrapper']/div[2]/div[2]/div[@class='user-goods-list']/div[1]/div//span[@class='ico']";
	public static final String Product_paymentPopup_Remove = "//div[@id='payment_item_delete_popup']/div[@class='popup__delete']/div[4]";
	public static final String Product_paymentPopup_moveToFavs = "//div[@id='payment_item_delete_popup']/div[@class='popup__delete']/div[3]";
	public static final String Product_paymentPopup_back = "/html//div[@id='payment_item_delete_popup']//span[@class='ico ico--back']";
	public static final String FinalBuy_button = "/html//form[@id='paymentBalanceForm']//button[@type='submit']";
	public static final String BackToMain_button = "/html//div[@id='wrapper']/div[@class='pay']/div[@class='pay__main']/div[2]//div[@class='pay__step-success']/div[1]/div[@class='pay__step-success-finish']/a[@href='https://www.zipy.co.il/']";
	public static final String Thanks_box = "/html//div[@id='wrapper']/div[@class='pay']/div[@class='pay__main']/div[2]//div[@class='pay__step-success']/div[1]/p[1]";

	
	
//// product quick-popup page: ////////////////////////////////////////////////////////

	public static final String ProductQuickPopup_variationsFirst ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']/div[@class='featherlight-content quick-view']/div[@class='featherlight-content-wrap']/div/section/div[@class='product__body']//div[@class='buy-options']/table[@class='product__params']/tbody/tr[1]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric']/p/span";
	public static final String ProductQuickPopup_variationsFirst_1 ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='buy-options']/table[@class='product__params']/tbody/tr[1]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric-items']/div/ul/li[2]/span";
	public static final String ProductQuickPopup_variationsFirst_2 ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='buy-options']/table[@class='product__params']/tbody/tr[1]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric-items']/div/ul/li[3]/span";
	public static final String ProductQuickPopup_variationsSecond ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']/div[@class='featherlight-content quick-view']/div[@class='featherlight-content-wrap']/div/section/div[@class='product__body']//div[@class='buy-options']/table[@class='product__params']/tbody/tr[2]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric']/p/span";
	public static final String ProductQuickPopup_variationsSecond_1 = "/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='buy-options']/table[@class='product__params']/tbody/tr[2]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric-items']/div/ul/li[2]/span";
	public static final String ProductQuickPopup_variationsSecond_2 = "/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='buy-options']/table[@class='product__params']/tbody/tr[2]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric-items']/div/ul/li[3]/span";
	public static final String ProductQuickPopup_variationsFirst_dropdownFrame = "/html/body/div[*]/div/div/div/div/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[2]/div[1]/div[1]";
	public static final String ProductQuickPopup_variationsSecond_dropdownFrame = "/html/body/div[*]/div/div/div/div/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[2]/td/div/div[2]/div[1]/div[1]";
	public static final String ProductQuickPopup_variationsThird ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']/div[@class='featherlight-content quick-view']/div[@class='featherlight-content-wrap']/div/section/div[@class='product__body']//div[@class='buy-options']/table[@class='product__params']/tbody/tr[3]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric']/p/span";
	public static final String ProductQuickPopup_variationsThird_1 ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='buy-options']/table[@class='product__params']/tbody/tr[3]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric-items']/div/ul/li[2]/span";
	public static final String ProductQuickPopup_variationsThird_2 ="/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='buy-options']/table[@class='product__params']/tbody/tr[3]/td/div[@class='product__params-selection']/div[@class='field__field']/div[1]/div[1]/div[@class='selectric-items']/div/ul/li[3]/span";
	public static final String ProductQuickPopup_variationsThird_dropdownFrame = "/html/body/div[*]/div/div/div/div/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[3]/td/div/div[2]/div[1]/div[1]";

	public static final String ProductQuickPopup_addToCart = "/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']//div[@class='featherlight-content-wrap']//section//div[@class='product__buy']/div[@class='product__buy-buttons']/a/span[@class='button__inner']";		
	public static final String ProductQuickPopup_PayNow_button = "/html/body/div[@role='dialog']/div[@class='featherlight-close-layer']/div[@class='featherlight-content quick-view']/div[@class='featherlight-content-wrap']//section//div[@class='product__buy']/div[@class='product__buy-buttons']/div[@class='product__buy-buttons-buy-now']/a[2]//span[@class='button__inner']";


	
//// gallery: ////////////////////////////////////////////////////////

	public static final String Product_galleryImage = "//*[@id=\"gallery\"]/figure/img";
	public static final String Product_galleryImage_left = "/html//div[@id='gallery']/div/a[2]/span[@class='ico ico--arrow']";
	public static final String Product_galleryImage_right = "/html//div[@id='gallery']/div/a[1]/span[@class='ico ico--arrow']";
	public static final String Product_galleryImage_bottom1 = "//*[@id=\"thumbs\"]/div[1]/a/div[1]/img";
	public static final String Product_galleryImage_bottom2 = "//*[@id=\"thumbs\"]/div[2]/a/div[1]/img";
	public static final String Product_galleryImage_bottom3 = "//*[@id=\"thumbs\"]/div[3]/a/div[1]/img";
	public static final String Product_gallery_nearVariation ="//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/div[3]/div[1]/table/tbody/tr[1]/td/div/div[1]/img";
	public static final String Product_notFound = "//div[@id='wrapper']//main[@role='main']/section[@class='notfound']//div[@class='notfound__text-title']";

	
	
//// product with variations: ////////////////////////////////////////////////////////
	
	//public static final String Product_noVariations = "https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/onebot-l2416-g4400-120g-ssd-4g-ddr4-1920-1080-23-8-all-in-one-computer-desktop-dual-core-all-in-one-pc-for-office-bussiness/32838774114/?utm_medium=email";
	public static final String Product_noVariations = "https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/sleeping-anti-schnarchen-nase-clip-silicone-magnetic-anti-snoring-nose-clips-breathing-stop-snore-apnea-antisnoring-clip-device/32952209706/?utm_medium=email";
	public static final String Product_noVariations2 = "https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/onebot-g32-31-5-inch-curved-led-gaming-monitor-144hz-1920-1080p-dvi-hd-ports-displayport-1800r-immersive-curvature/32887298148/?utm_medium=email";
	public static final String Product_noVariationsAmazon = "https://www.zipy.co.il/p/amazon/bm-premium-bp718-bp727-battery-charger-for-canon-hfr80-hfr82-hfr800-hfr70-hfr72-hfr700-hfm52-hfm500-hfr30-hfr32-hfr300-hfr40-hfr42-hfr400-hfr50-hfr52-hfr500-hfr60-hfr62-hfr600/B009ZWNKQ0/";
	public static final String Product_oneVariation = "https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/A/32958346076/?utm_medium=email";
	//one variation:  https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/A/32847534585/?utm_medium=email
	public static final String Product_twoVariations = "https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/rez-micro-usb-cable-usb-charging-cord-mobile-phone-nylon-xiaomi-android-samsung-for-hua-wei/32995752928/?utm_medium=email";
	//no variations and no delivery : https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/sleeping-anti-schnarchen-nase-clip-silicone-magnetic-anti-snoring-nose-clips-breathing-stop-snore-apnea-antisnoring-clip-device/32952209706/?utm_medium=email

	public static final String ProductWithColors = "https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/painter-hat-caps-beret-female-french-vintage-women-s-lady-street-cap-girl-s-warm-solid/4000115814986/?utm_medium=email";

	
	
//// products lists: ////////////////////////////////////////////////////////

	public static final String lessThan5_Open ="/html/body/div[@class='wrap wrap_with_mehes']//ul[@class='stores']//a/span";
	public static final String lessThan5_dealThumbnail1 = "//*[@id=\"wrapper\"]/div[2]/main/section[2]/div[2]/div[1]/a";
	public static final String Product_sortBy = "//div[@id='wrapper']//main[@role='main']/section[@class='daily m--category m--plates']//div[@class='daily__heading-sort-item daily__heading-sort-item-sort-by']";
	public static final String Product_toysTitle = "/html//div[@id='wrapper']//main[@role='main']/div[@class='elementor elementor-21138']//div[@class='elementor-section-wrap']/section[1]//div[@class='elementor-row']/div//div[@class='elementor-element elementor-element-3f21537b elementor-widget elementor-widget-heading']//h2[@class='elementor-heading-title elementor-size-default']";
	
	
	
//// aliexpress: ////////////////////////////////////////////////////////
	
	public static final String Aliexpress_PopupClose = "/html/body/div[5]//a[@href='javascript:;']";
	public static final String Aliexpress_Localization ="//a[@id='switcher-info']/span[@class='currency']";
	public static final String Aliexpress_PopupCurrency = "/html//div[@id='nav-global']/div[4]//div[@class='switcher-currency-c']/span[@class='select-item']";
	public static final String Aliexpress_PopupCurrency_NIS = "/html//div[@id='nav-global']//div[@class='switcher-currency-c']/ul[@class='notranslate']/li[112]/a[@href='javascript:;']/em[.=' (  Israeli New Shekel  )']";
	public static final String Aliexpress_Localization_Save = "/html//div[@id='nav-global']/div[4]//button[@type='button']";
	
	
	
//// search: ////////////////////////////////////////////////////////
	
	public static final String SearchItemAli =	"rez-micro-usb-cable-usb-charging-cord-mobile-phone-nylon-xiaomi-android-samsung-for-hua-wei";
	public static final String SearchItemAli_thumb ="//div[@data-id='32995752928'][@data-position='1']";
	public static final String SearchItemAli_link ="https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/rez-micro-usb-cable-usb-charging-cord-mobile-phone-nylon-xiaomi-android-samsung-hua-wei/32995752928/";
	public static final String SearchItemAli_link2 ="https://www.zipy.co.il/p/%D7%90%D7%9C%D7%99%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1/minhin-simulated-pearl-stud-earrings-women-bohemian-geometric-earrings-wedding-jewelry-korean-earrings/4000151362225/";
	public static final String SearchItemAmazon_link ="https://www.zipy.co.il/p/amazon/bic-round-stic-xtra-life-ballpoint-pen-medium-point-1-0mm-black-36-count-36-count/B00347A8NK/";
		
	public static final String Search_eng = "nike";
	public static final String Search_heb = "נייק";
	public static final String Search_pt1 = "eletrónica  preços  ";
	public static final String Search_pt2 = "Futevôlei Cão ";
	public static final String Search_itemOnAliexpressOnly = "yuanqishun";
	public static final String Search_itemNotOnAliexpress = "judea pearl";
	public static final String Search_itemEverywhere = "dress";

	public static final String Search_special_apostrophe = "Zoy’s dress";
	public static final String Search_special_dash = "dell-23";
	public static final String Search_special_parenthesis = "taifu (12V)";
	public static final String Search_special_bracket = "[sintron]";
	public static final String Search_content = "//*[@id=\"desktop_search_fild\"]";
	public static final String Search_orderBy_mobile = "//*[@id=\"wrapper\"]/div[3]/main/section/div[1]/div[2]/a[1]";
	public static final String Search_notFound = "//div[@id='wrapper']//main[@role='main']/section//div[@class='notfound__text-title']";
	public static final String Search_link_aliExpress = "https://www.aliexpress.com/item/4000392639189.html?spm=a2g0o.productlist.0.0.264a5504i6FRuu&algo_pvid=b9ee8b5f-c6e2-4552-a37d-ee9330c45486&algo_expid=b9ee8b5f-c6e2-4552-a37d-ee9330c45486-2&btsid=2e665580-6c2e-49dd-8ee1-899d1d4257f4&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53";
	public static final String Search_link_aliExpress_title = "//*[@id=\"root\"]/div/div[2]/div/div[2]/div[1]";
	public static final String Search_link_ebay = "https://www.ebay.com/itm/ASICS-Womens-GEL-Nimbus-21-Running-Shoe/223546838586?_trkparms=5079%3A5000014535";
	public static final String Search_link_ebay_title = "/html/head/meta[20]"; //atribute:content
	public static final String Search_link_amazon = "https://www.amazon.com/Under-Armour-Womens-Play-Shorts/dp/B07Q33MCBR?pf_rd_p=e7ce1c29-3021-5430-acf8-3180e1263e92&pf_rd_r=SBXEZ2MV62HTWJNF6VR7&pd_rd_wg=2fIUM&ref_=pd_gw_ri&pd_rd_w=bNVEO&pd_rd_r=d28eb397-9195-4fcf-a6ce-197e3510eeff";
	public static final String Search_link_amazon_title = "//*[@id=\"productTitle\"]";
	public static final String Search_link_amazon_zipyTitle = "/html/head/meta[6]"; //atribute:content
	public static final String Search_link_ebayDE = "https://www.ebay.de/itm/Big-Seven-Brian-Cargo-Hose-Comfort-Fit-Herren-Jeans-Hose/401091823499?_trkparms=pageci%3Aaaa79ac8-41dd-11ea-9c7c-74dbd180bd02%7Cparentrq%3Aeca2cb1b16f0a4b7fcbeb1e9fff8bb0a%7Ciid%3A1";
	public static final String Search_link_ebayDY_title = "/html/head/meta[15]"; //atribute:content
	public static final String Search_link_amazonDE = "https://www.amazon.de/Boldog-Laube-kuscheliger-Schal-Cashmerefeeling/dp/B00CYDMC0M?pf_rd_p=fc3dc759-a057-4598-848d-dce8d6cdd7c9&pd_rd_wg=hnUg5&pf_rd_r=Y7AGS67WZQ5SXGV657QR&ref_=pd_gw_unk&pd_rd_w=tCY9C&pd_rd_r=7592bd9b-9226-49ed-8d8d-27307d388f08";
	public static final String Search_autocompleteArrow1 = "/html//form[@id='searchbar-form-one-block-page']/div/div/span[1]/span[@class='ico ico--autocomplete']";
	public static final String Search_autocompleteHint1 = "/html//form[@id='searchbar-form-one-block-page']/div/div/span[1]/span[@class='autocomplete_hint']";
	public static final String Search_button = "//form[@id='searchbar-form-one-block-page']//span[@class='ico ico--magnifier']";
	public static final String Search_delete = "/html//form[@id='searchbar-form-one-block-page']//span[@class='ico ico--cross']";
	public static final String Search_redirect = "//div[@id='wrapper']//main[@role='main']/section[@class='message-redirect']/div";
	public static final String Search_smartSearchButton = "//div[@id='wrapper']//main[@role='main']/section[@class='shop-switch']//span[@class='switch__slider']";

	
	
//// errors: ////////////////////////////////////////////////////////

	public static final String error_502 = "/html//h1[.='502 Bad Gateway']";
	public static final String error_oops = "/html//h1[.='Oops! :(']";
	public static final String error_502_type2 ="/html//div[@id='cf-error-details']//span[@class='cf-error-code']";

	
}
