package zipy_elements;

public class ElementsHeb {

	public static final String ThanksForBuying_heb = "תודה על ההזמנה";
	public static final String SignedIn_ezorIshi = "אזור אישי";



}
