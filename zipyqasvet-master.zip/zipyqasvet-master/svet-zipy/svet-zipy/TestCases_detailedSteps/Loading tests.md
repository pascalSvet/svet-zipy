
## Loading  tests
----


### Loading :

<details>
<summary><strong>presence of loader-spinner on thumbnail click</strong></summary> 
<p> 
  
- open the deals page
- click on thumbnail and check its spinner element
- if correct, spinner displayed
</p>
</details> 
 
<details>

<summary><strong>updating of loader-spinner after clicking on another thumbnail</strong></summary>  
 <p> 
    
- open the deals page
- click one thumbnail and then another one and check their spinner elements
- if correct, spinner displayed on the second thumbnail only
</p>
</details> 
  
----

### Loading_mobile:

<details>
<summary><strong>TestsMobile - presence of loader-spinner on thumbnail click</strong></summary> 
<p> 
   
- change to mobile screen resolution
- open the deals page
- click on thumbnail and check its spinner element
- if correct, spinner displayed
 </p>
</details> 
   
<details>
<summary><strong>TestsMobile - updating of loader-spinner after clicking on another thumbnail</strong></summary> 
 <p> 
   
- change to mobile screen resolution
- open the deals page
- click one thumbnail and then another one and check their spinner elements
- if correct, spinner displayed on the second thumbnail only
 </p>
</details> 
 

 
  