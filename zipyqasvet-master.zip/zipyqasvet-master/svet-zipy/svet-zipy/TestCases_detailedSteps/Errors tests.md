
## Error tests
----

### Errors_502:


<details>
<summary><strong>catching 502 error while opening many tabs in categories - Greece</strong></summary>
<p>
  
- open main page
- open first category from catalog, and open first 17 items in different tabs
- if correct, all categories loaded
</p>
</details> 
      
<details>
<summary><strong>catching 502 error while opening many tabs in categories - Portugal</strong></summary> 
<p>
     
- open main page
- open first category from catalog, and open first 17 items in different tabs
- if correct, all categories loaded
</p>
</details> 
              
<details>
<summary><strong>catching 502 error while opening many tabs in categories - Israel</strong></summary>
<p>
    
- open main page
- open first category from catalog, and open first 17 items in different tabs
- if correct, all categories loaded
</p>
</details> 
      		
<details>
<summary><strong>catching 502 error while opening many tabs in deals - Greece</strong></summary>
<p>
    
- open deals page
- scroll down and open first 16 deals in different tabs
- if correct, all deals loaded
</p>
</details> 
   
<details>
<summary><strong>catching 502 error while opening many tabs in deals - Portugal</strong></summary>
 <p>
   
- open deals page
- scroll down and open first 16 deals in different tabs
- if correct, all deals loaded
</p>
</details> 
  
<details>
<summary><strong>catching 502 error while opening many tabs in deals - Israel</strong></summary>
 <p>
   
- open deals page
- scroll down and open first 16 deals in different tabs
- if correct, all deals loaded
</p>
</details>  
 