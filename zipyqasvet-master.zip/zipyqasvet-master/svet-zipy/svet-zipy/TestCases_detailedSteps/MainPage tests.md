
## MainPage   tests
----


### MainPageThumbs_greece :

<details>
<summary><strong>opening main page thumbnails in Greece site</strong></summary> 
<p> 
  
- open the main page
- open all thumbnails in different tabs, and check if any of them  failed to open
- if we managed to open all products correctly, there will be no fails
</p>
</details> 

<details>
<summary><strong>opening main page thumbnails in Greece site - ebay</strong></summary>  
<p> 
     
- open the main ebay page
- open all thumbnails in different tabs, and check if any of them  failed to open
- if we managed to open all products correctly, there will be no fails
</p>
</details> 

<details>
<summary><strong>opening main page thumbnails in Greece site - amazon</strong></summary> 
<p> 
    
- open the main amzon page
- open all thumbnails in different tabs, and check if any of them  failed to open
- if we managed to open all products correctly, there will be no fails
</p>
</details> 
 
----

### MainPageThumbs_israel:

<details>
<summary><strong>opening main page thumbnails in Israel site</strong></summary> 
<p> 
    
- open the main page
- open all thumbnails in different tabs, and check if any of them  failed to open
- if we managed to open all products correctly, there will be no fails
</p>
</details> 

   