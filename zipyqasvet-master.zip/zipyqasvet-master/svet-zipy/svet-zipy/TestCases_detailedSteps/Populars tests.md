
## Populars  tests
----


### Israel site:

<details>
<summary><strong>populars thumbnails on aliExpress page</strong></summary>
<p> 
  
- open the main page
- opening all thumbnails in different tabs and check their loading
- if we managed to open all products correctly, there will be no fails:
</p>
</details> 

----

### Greece site:

<details>
<summary><strong>populars thumbnails on aliExpress page</strong></summary>  
<p> 
    
- open the main page
- opening all thumbnails in different tabs and check their loading
- if we managed to open all products correctly, there will be no fails:
</p>
</details> 
  
<details>
<summary><strong>populars thumbnails on ebay page</strong></summary> 
<p> 
      
- open the main ebay page
- opening all thumbnails in different tabs and check their loading
- if we managed to open all products correctly, there will be no fails:  
</p>
</details> 

<details>
<summary><strong>populars thumbnails on amazon page</strong></summary>     
<p> 
    
- open the main amazon page
- opening all thumbnails in different tabs and check their loading
- if we managed to open all products correctly, there will be no fails:
</p>
</details> 

----

### Cyprus site:

<details>
<summary><strong>populars thumbnails on aliExpress page</strong></summary> 
<p>   
test details here are the same as in Greece test case  
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on ebay page</strong></summary>
<p> 
test details here are the same as in Greece test case     
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on amazon page</strong></summary>   
<p>
test details here are the same as in Greece test case   
</p>
</details> 
    




### Romania site:

<details>
<summary><strong>populars thumbnails on aliExpress page</strong></summary> 
<p>   
test details here are the same as in Greece test case  
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on ebay page</strong></summary>
<p> 
test details here are the same as in Greece test case     
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on amazon page</strong></summary>   
<p>
test details here are the same as in Greece test case   
</p>
</details> 
     


### Italy site:

<details>
<summary><strong>populars thumbnails on aliExpress page</strong></summary> 
<p>   
test details here are the same as in Greece test case  
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on ebay page</strong></summary>
<p> 
test details here are the same as in Greece test case     
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on amazon page</strong></summary>   
<p>
test details here are the same as in Greece test case   
</p>
</details> 
     


### Portugal site:

<details>
<summary><strong>populars thumbnails on aliExpress page</strong></summary> 
<p>   
test details here are the same as in Greece test case  
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on ebay page</strong></summary>
<p> 
test details here are the same as in Greece test case     
</p>
</details> 
   
<details>
<summary><strong>populars thumbnails on amazon page</strong></summary>   
<p>
test details here are the same as in Greece test case   
</p>
</details> 
    
