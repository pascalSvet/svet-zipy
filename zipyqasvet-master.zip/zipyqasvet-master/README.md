# ZipyQASvet

