
## Catalogs tests
----


### Сatalogs_il_aliExpress_combined

<details>
<summary><strong>opening all sub categories in aliExpress - Israel (with parameters)</strong></summary>
<p>      

- our parameters to test- categories in the catalog: 
    - fashion
    - cars 
    - electronics  
    - computers   
    - photography   
    - cellular   
    - house and garden   
    - jewelry and watches

- open main page and close the pop-up if it's the first parameter
- open the aliExpress tab
- open the categories catalog
- save all links from the current category
- open each link in current category, one by one
- if failed to load, return the category name and its link
- return the number of fails in current category
- if everything opened correct, then no fails caught
</p>
</details> 


### Сatalogs_il_aliExpress_separated

<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 1 category - fashion</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
 
<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 2 category - cars</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
 
<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 3 category - electronics</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
   
<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 4 category - computers</strong></summary>     
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 5 category - photography</strong></summary> 
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
    
<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 6 category - cellular</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
   
<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 7 category - house and garden</strong></summary> 
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
    
<details>
<summary><strong>opening all sub categories in aliExpress - Israel - 8 category - jewelry and watches</strong></summary>
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
     


### Сatalogs_il_amazon_combined

 <details>
 <summary><strong>opening all sub categories in amazon - Israel (with parameters)</strong></summary>
 <p>   

- our parameters to test- categories in the catalog:  
    - fashion
    - cars 
    - electronics  
    - computers   
    - photography   
    - cellular   
    - house and garden   
    - jewelry and watches
    - books
    
- open main page and close the pop-up if it's the first parameter
- open the amazon tab
- open the categories catalog
- save all links from the current category
- open each link in current category, one by one
- if failed to load, return the category name and its link
- return the number of fails in current category
- if everything opened correct, then no fails caught
 </p>
</details> 


### Сatalogs_il_amazon_separated

<details>
<summary><strong>opening all sub categories in amazon - Israel - 1 category - fashion</strong></summary> 
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
 
<details>
<summary><strong>opening all sub categories in amazon - Israel - 2 category - cars</strong></summary>   
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
 
<details>
<summary><strong>opening all sub categories in amazon - Israel - 3 category - electronics</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
    
<details>
<summary><strong>opening all sub categories in amazon - Israel - 4 category - computers</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
   
<details>
<summary><strong>opening all sub categories in amazon - Israel - 5 category - photography</strong></summary>   
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
   
<details>
<summary><strong>opening all sub categories in amazon - Israel - 6 category - cellular</strong></summary>    
 <p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in amazon - Israel - 7 category - house and garden</strong></summary>   
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
 
<details>
<summary><strong>opening all sub categories in amazon - Israel - 8 category - jewelry and watches</strong></summary>
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in amazon - Israel - 9 category - books</strong></summary>
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 



### Сatalogs_gr_aliExpress_combined

<details>
<summary><strong>opening all sub categories in aliExpress - Greece (with parameters)</strong></summary>
<p>    

- our parameters to test- categories in the catalog:
    - fashion
    - cars 
    - electronics  
    - computers   
    - photography   
    - cellular   
    - house and garden   
    - jewelry and watches

- open main page and close the pop-up if it's the first parameter
- open the aliExpress tab
- open the categories catalog
- save all links from the current category
- open each link in current category, one by one
- if failed to load, return the category name and its link
- return the number of fails in current category
- if everything opened correct, then no fails caught
 </p>
</details> 


### Сatalogs_gr_aliExpress_separated

<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 1 category - fashion</strong></summary> 
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
  
<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 2 category - cars</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 3 category - electronics</strong></summary> 
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>  
   
<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 4 category - computers</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 5 category - photography</strong></summary>  
 <p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
  
<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 6 category - cellular</strong></summary>     
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 7 category - house and garden</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>   
 
<details>
<summary><strong>opening all sub categories in aliExpress - Greece - 8 category - jewelry and watches</strong></summary>
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
  
  
  
### Сatalogs_gr_amazon_combined

<details>
<summary><strong>opening all sub categories in amazon - Greece (with parameters)</strong></summary>
<p>   

- our parameters to test- categories in the catalog:
    - fashion
    - cars 
    - electronics  
    - computers   
    - photography   
    - cellular   
    - house and garden   
    - jewelry and watches
    - books
     
- open main page and close the pop-up if it's the first parameter
- open the amazon tab
- open the categories catalog
- save all links from the current category
- open each link in current category, one by one
- if failed to load, return the category name and its link
- return the number of fails in current category
- if everything opened correct, then no fails caught
</p>
</details> 


### Сatalogs_gr_amazon_separated


<details>
<summary><strong>opening all sub categories in amazon - Greece - 1 category - fashion</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
 
<details>
<summary><strong>opening all sub categories in amazon - Greece - 2 category - cars</strong></summary>   
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in amazon - Greece - 3 category - electronics</strong></summary>  
 <p>   
test details here are the same as on parameterized test case  
 </p>
</details>  

<details>
<summary><strong>opening all sub categories in amazon - Greece - 4 category - computers</strong></summary>  
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>  
  
<details>
<summary><strong>opening all sub categories in amazon - Greece - 5 category - photography</strong></summary>   
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
  
<details>
<summary><strong>opening all sub categories in amazon - Greece - 6 category - cellular</strong></summary>    
<p>   
test details here are the same as on parameterized test case  
 </p>
</details>
  
<details>
<summary><strong>opening all sub categories in amazon - Greece - 7 category - house and garden</strong></summary> 
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
    
<details>
<summary><strong>opening all sub categories in amazon - Greece - 8 category - jewelry and watches</strong></summary>
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 

<details>
<summary><strong>opening all sub categories in amazon - Greece - 9 category - books</strong></summary>
<p>   
test details here are the same as on parameterized test case  
 </p>
</details> 
