
# User  tests


### User_password:

<details><summary><strong>changing the password</strong></summary>
<p>   
   
- enter main page
- enter private data and change password 
- if changed correctly, there is a success message
- change the password back at the end, for future tests
</p>
</details> 
   
<details>
<summary><strong>recovering the password    !!!user input required!!!</strong></summary> 
<p>   
   
- enter main page and disconnect from the user
- press login button		
- recover the password by email 
-  ask user to enter the new password from the email: 		
- if recovered successfully, the user logged in
- change the password back at the end, for future tests
</p>
</details> 
 	
----

### User_email:

<details>
<summary><strong>changing the email</strong></summary> 
<p>   
   
- enter main page
- enter private data and change password 
- if changed correctly, there is a success message
- change the email back at the end, for future tests
</p>
</details> 

----
 
### User_mobile:

<details>
<summary><strong>TestsMobile - changing the password</strong></summary>
<p>   
   
- change to mobile screen resolution and enter main page
- enter private data and change password 
- if changed correctly, there is a success message
- change the password back at the end, for future tests
</p>
</details> 
    
<details>
<summary><strong>TestsMobile - changing the email</strong></summary> 
 <p>   
   
- change to mobile screen resolution and enter main page
- enter private data and change email 
- if changed correctly, there is a success message
- change the password back at the end, for future tests
 </p>
</details> 
    